import os
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
from pymongo import DESCENDING, MongoClient


BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR / "udb"

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "moviehub")

app = Flask(__name__, static_folder=str(FRONTEND_DIR), static_url_path="")

mongo_client = MongoClient(MONGO_URI)
db = mongo_client[MONGO_DB_NAME]
movies_collection = db["movies"]
reviews_collection = db["reviews"]


def init_db() -> None:
    movies_collection.create_index("movie_name")
    movies_collection.create_index("genre")
    reviews_collection.create_index("movie")
    reviews_collection.create_index([("rating", DESCENDING)])


def serialize_document(document: dict) -> dict:
    serialized = dict(document)
    serialized["id"] = str(serialized.pop("_id"))
    created_at = serialized.get("created_at")
    if isinstance(created_at, datetime):
        serialized["created_at"] = created_at.isoformat()
    return serialized


@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response


@app.route("/movies", methods=["GET", "POST", "OPTIONS"])
def movies():
    if request.method == "OPTIONS":
        return ("", 204)

    if request.method == "POST":
        payload = request.get_json(silent=True) or {}
        movie_name = (payload.get("movie_name") or "").strip()
        genre = (payload.get("genre") or "").strip()
        year = payload.get("year")
        description = payload.get("description")
        image = payload.get("image")

        if not movie_name or not genre:
            return jsonify({"error": "movie_name and genre are required"}), 400

        if year == "":
            year = None

        if year is not None:
            try:
                year = int(year)
            except (TypeError, ValueError):
                return jsonify({"error": "year must be a number"}), 400

        movie = {
            "movie_name": movie_name,
            "genre": genre,
            "year": year,
            "description": description,
            "image": image,
            "created_at": datetime.now(timezone.utc),
        }

        result = movies_collection.insert_one(movie)
        return jsonify({"message": "Movie added successfully", "id": str(result.inserted_id)}), 201

    movies_list = [
        serialize_document(movie)
        for movie in movies_collection.find().sort("created_at", DESCENDING)
    ]
    return jsonify(movies_list)


@app.route("/movies/search", methods=["GET"])
def search_movies():
    query = (request.args.get("q") or "").strip()
    if not query:
        return jsonify([])

    search_filter = {
        "$or": [
            {"movie_name": {"$regex": query, "$options": "i"}},
            {"genre": {"$regex": query, "$options": "i"}},
        ]
    }

    matches = [
        serialize_document(movie)
        for movie in movies_collection.find(search_filter).sort("movie_name", 1)
    ]
    return jsonify(matches)


@app.route("/movies/top", methods=["GET"])
def top_movies():
    pipeline = [
        {
            "$lookup": {
                "from": "reviews",
                "let": {"movieName": {"$toLower": "$movie_name"}},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {
                                "$eq": [{"$toLower": "$movie"}, "$$movieName"]
                            }
                        }
                    }
                ],
                "as": "matched_reviews",
            }
        },
        {
            "$addFields": {
                "reviewCount": {"$size": "$matched_reviews"},
                "avgRating": {"$avg": "$matched_reviews.rating"},
            }
        },
        {
            "$match": {
                "reviewCount": {"$gt": 0}
            }
        },
        {
            "$project": {
                "_id": 1,
                "movie_name": 1,
                "genre": 1,
                "year": 1,
                "description": 1,
                "image": 1,
                "reviewCount": 1,
                "avgRating": {"$round": ["$avgRating", 2]},
                "created_at": 1,
            }
        },
        {"$sort": {"avgRating": -1, "reviewCount": -1, "movie_name": 1}},
        {"$limit": 10},
    ]

    leaderboard = [
        serialize_document(movie)
        for movie in movies_collection.aggregate(pipeline)
    ]
    return jsonify(leaderboard)


@app.route("/reviews", methods=["GET", "POST", "OPTIONS"])
def reviews():
    if request.method == "OPTIONS":
        return ("", 204)

    if request.method == "POST":
        payload = request.get_json(silent=True) or {}
        movie = (payload.get("movie") or "").strip()
        user = (payload.get("user") or "").strip()
        review_text = (payload.get("review") or "").strip()
        rating = payload.get("rating")

        try:
            rating = int(rating)
        except (TypeError, ValueError):
            rating = None

        if not movie or not user or not review_text or rating is None:
            return jsonify({"error": "movie, user, rating, and review are required"}), 400

        if rating < 1 or rating > 5:
            return jsonify({"error": "rating must be between 1 and 5"}), 400

        review = {
            "movie": movie,
            "user": user,
            "rating": rating,
            "review": review_text,
            "created_at": datetime.now(timezone.utc),
        }

        result = reviews_collection.insert_one(review)
        return jsonify({"message": "Review added successfully", "id": str(result.inserted_id)}), 201

    reviews_list = [
        serialize_document(review)
        for review in reviews_collection.find().sort("created_at", DESCENDING)
    ]
    return jsonify(reviews_list)


@app.route("/")
def home():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/<path:path>")
def static_files(path: str):
    return send_from_directory(FRONTEND_DIR, path)


init_db()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
