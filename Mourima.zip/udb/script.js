const API = "http://localhost:5000"; // backend URL

// Show Toast Notification
function showToast(message, type = "success", duration = 3000) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  
  setTimeout(() => {
    toast.classList.remove("show");
  }, duration);
}

// Validate Input
function validateInput(value, type = "text") {
  if (type === "rating") {
    const num = parseInt(value);
    return num >= 1 && num <= 5;
  }
  return value.trim().length > 0;
}

// Set Button Loading State
function setButtonLoading(button, isLoading) {
  if (isLoading) {
    button.classList.add("loading");
    button.disabled = true;
  } else {
    button.classList.remove("loading");
    button.disabled = false;
  }
}

// Add Movie
async function addMovie(event) {
  event.preventDefault();
  
  const movieName = document.getElementById("movieName");
  const genre = document.getElementById("genre");
  const button = event.target.querySelector("button");

  // Validation
  if (!validateInput(movieName.value)) {
    showToast("Please enter a movie name", "error");
    movieName.focus();
    return;
  }

  if (!validateInput(genre.value)) {
    showToast("Please enter a genre", "error");
    genre.focus();
    return;
  }

  try {
    setButtonLoading(button, true);

    const response = await fetch(`${API}/movies`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        movie_name: movieName.value.trim(), 
        genre: genre.value.trim() 
      })
    });

    if (!response.ok) {
      throw new Error("Failed to add movie");
    }

    showToast("✓ Movie added successfully!", "success");
    event.target.reset();
    movieName.focus();

  } catch (error) {
    console.error(error);
    showToast("Error: Failed to add movie", "error");
  } finally {
    setButtonLoading(button, false);
  }
}

// Add Review
async function addReview(event) {
  event.preventDefault();

  const reviewMovie = document.getElementById("reviewMovie");
  const userName = document.getElementById("userName");
  const rating = document.getElementById("rating");
  const reviewText = document.getElementById("reviewText");
  const button = event.target.querySelector("button");

  // Validation
  if (!validateInput(reviewMovie.value)) {
    showToast("Please enter a movie name", "error");
    reviewMovie.focus();
    return;
  }

  if (!validateInput(userName.value)) {
    showToast("Please enter your name", "error");
    userName.focus();
    return;
  }

  if (!validateInput(rating.value, "rating")) {
    showToast("Please enter a rating between 1-5", "error");
    rating.focus();
    return;
  }

  if (!validateInput(reviewText.value)) {
    showToast("Please write a review", "error");
    reviewText.focus();
    return;
  }

  try {
    setButtonLoading(button, true);

    const response = await fetch(`${API}/reviews`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        movie: reviewMovie.value.trim(), 
        user: userName.value.trim(), 
        rating: parseInt(rating.value), 
        review: reviewText.value.trim() 
      })
    });

    if (!response.ok) {
      throw new Error("Failed to add review");
    }

    showToast("✓ Review submitted successfully!", "success");
    event.target.reset();
    reviewMovie.focus();

  } catch (error) {
    console.error(error);
    showToast("Error: Failed to submit review", "error");
  } finally {
    setButtonLoading(button, false);
  }
}

// Search Movie
async function searchMovie(event) {
  event.preventDefault();

  const searchInput = document.getElementById("searchInput");
  const button = event.target.querySelector("button");
  const resultsContainer = document.getElementById("searchResults");

  const query = searchInput.value.trim();

  if (!query) {
    showToast("Please enter a search term", "error");
    searchInput.focus();
    return;
  }

  try {
    setButtonLoading(button, true);
    resultsContainer.innerHTML = "";

    const response = await fetch(`${API}/movies/search?q=${encodeURIComponent(query)}`);
    
    if (!response.ok) {
      throw new Error("Search failed");
    }

    const data = await response.json();

    if (!data || data.length === 0) {
      showToast("No movies found", "error");
      return;
    }

    showToast(`✓ Found ${data.length} result(s)`, "success");

    data.forEach(movie => {
      const div = document.createElement("div");
      div.className = "result-item";
      div.innerHTML = `
        <strong>${movie.movie_name || "Unknown"}</strong>
        <div style="font-size: 0.9em; opacity: 0.8; margin-top: 5px;">
          ${movie.genre ? `Genre: ${movie.genre}` : ""}
        </div>
      `;
      resultsContainer.appendChild(div);
    });

  } catch (error) {
    console.error(error);
    showToast("Error: Failed to search", "error");
  } finally {
    setButtonLoading(button, false);
  }
}

// Get Leaderboard
async function getLeaderboard() {
  const button = event.target;
  const leaderboardContainer = document.getElementById("leaderboard");

  try {
    setButtonLoading(button, true);
    leaderboardContainer.innerHTML = "";

    const response = await fetch(`${API}/movies/top`);
    
    if (!response.ok) {
      throw new Error("Failed to fetch leaderboard");
    }

    const data = await response.json();

    if (!data || data.length === 0) {
      showToast("No movies in leaderboard yet", "error");
      return;
    }

    showToast(`✓ Leaderboard loaded (${data.length} movies)`, "success");

    data.forEach((movie, index) => {
      const div = document.createElement("div");
      div.className = "leaderboard-item";
      const rating = parseFloat(movie.avgRating || 0).toFixed(1);
      const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `#${index + 1}`;
      
      div.innerHTML = `
        <div>
          <strong>${medal} ${movie.movie_name || "Unknown"}</strong>
        </div>
        <div class="rating-badge">⭐ ${rating}</div>
      `;
      leaderboardContainer.appendChild(div);
    });

  } catch (error) {
    console.error(error);
    showToast("Error: Failed to load leaderboard", "error");
  } finally {
    setButtonLoading(button, false);
  }
}

// Display Movie Gallery with Images
async function displayMovieGallery() {
  const button = document.querySelector("#galleryLoader").closest("button");
  const galleryContainer = document.getElementById("movieGallery");

  try {
    setButtonLoading(button, true);
    galleryContainer.innerHTML = "";

    const response = await fetch(`${API}/movies`);
    
    if (!response.ok) {
      throw new Error("Failed to fetch movies");
    }

    const movies = await response.json();

    if (!movies || movies.length === 0) {
      galleryContainer.innerHTML = '<div class="no-gallery-message">📽️ No movies in gallery yet. Add a movie first!</div>';
      showToast("No movies available", "error");
      return;
    }

    showToast(`✓ Loaded ${movies.length} movie(s)`, "success");

    movies.forEach(movie => {
      const galleryItem = document.createElement("div");
      galleryItem.className = "gallery-item";
      
      // Use placeholder image or stored image
      const imageUrl = movie.image || `https://via.placeholder.com/160x200?text=${encodeURIComponent(movie.movie_name)}`;
      
      galleryItem.innerHTML = `
        <img src="${imageUrl}" alt="${movie.movie_name}" onerror="this.src='https://via.placeholder.com/160x200?text=No+Image'">
        <div class="gallery-info">
          <h3>${movie.movie_name || "Unknown"}</h3>
          <p>${movie.genre || "N/A"}</p>
        </div>
      `;
      
      galleryContainer.appendChild(galleryItem);
    });

  } catch (error) {
    console.error(error);
    galleryContainer.innerHTML = '<div class="no-gallery-message">❌ Failed to load gallery. Try again!</div>';
    showToast("Error: Failed to load gallery", "error");
  } finally {
    setButtonLoading(button, false);
  }
}

// Store Movie Image as Base64 (optional - for localStorage demo)
function handleImageUpload(event) {
  const fileInput = document.getElementById("movieImage");
  const file = fileInput.files[0];
  
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    const base64Image = e.target.result;
    // You can store this base64 string to send with the movie
    // Or use it for preview
    console.log("Image uploaded as base64:", base64Image.substring(0, 50) + "...");
  };
  reader.readAsDataURL(file);
}